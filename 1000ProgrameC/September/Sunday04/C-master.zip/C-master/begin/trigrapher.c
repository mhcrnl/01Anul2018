??=include <stdio.h>
??=include <stdlib.h>

/*
 * Compile: gcc -Wall -trigraphs trigrapher -o trigraph
 */

int
main(int argc, char** argv)
??<
	printf("Something funny went on\n");
	exit(EXIT_SUCCESS);
??>
