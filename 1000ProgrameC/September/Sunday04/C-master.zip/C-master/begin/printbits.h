#ifndef _PRINT_BITS
#define _PRINT_BITS

#include <stdio.h>
#include <stdlib.h>

void print_bits(int);

#endif
