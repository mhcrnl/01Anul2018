char *
hello()
{
  return "Hello";
}
