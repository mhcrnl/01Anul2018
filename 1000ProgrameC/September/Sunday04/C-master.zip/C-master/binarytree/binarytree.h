#ifndef _BINARYTREE_H
#define _BINARYTREE_H

struct tree_node {
	int data;	/* Or whatever you'd like */
	struct tree_node *left_p, *right_p;
};

#endif/*_BINARYTREE_H*/
