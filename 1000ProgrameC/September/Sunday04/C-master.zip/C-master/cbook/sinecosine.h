#ifndef _SINECOSINE_H
#define _SINECOSINE_H

#include <stdlib.h>
#include <stdio.h>

long double sinus(long double);
long double cosinus(long double);

#endif
