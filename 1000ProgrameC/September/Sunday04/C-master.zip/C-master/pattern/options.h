#ifndef _OPTIONS_H
#define _OPTIONS_H

#include <stdio.h>
#include <string.h>

int options(int, char**, const char*);

#endif /* _OPTIONS_H */
