http://wiki.csie.ncku.edu.tw/embedded/2016q1h1

```
$ make run
$ make cache-test
$ make plot
```

Licensing
---------
`phonebook` is freely redistributable under the two-clause BSD License.
Use of this source code is governed by a BSD-style license that can be found
in the `LICENSE` file.
